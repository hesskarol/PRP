package controller;

import java.util.Date;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.util.Duration;

public class RotationWindowController {
	
	private Main main;
	private Stage primaryStage;
	
	@FXML ImageView image;
	@FXML Button stopButton;
	@FXML Label resultLabel;
	
	
	private double wheelPressedX, wheelPressedY;
	private double wheelPressedAngle;
	private double cursorOffset;
	private boolean dragBeginFlag = true;
	private double oldRot;
	private double newRot;	
	private Date oldTime;
	private Date newTime;
	private double wheelVelocity;
	private Wheel wheel;


	public void wheelPressed(MouseEvent evt) {
		
		wheelPressedX = evt.getSceneX()-250;
		wheelPressedY = evt.getSceneY()-250;
		wheelPressedAngle = Math.toDegrees(Math.atan2(wheelPressedY, wheelPressedX));
		cursorOffset =  wheelPressedAngle - wheel.getRotate();		
	}
	
	public void wheelDragged(MouseEvent evt) 
		{
		wheelPressedX = evt.getSceneX()-250;
		wheelPressedY = evt.getSceneY()-250;		
		wheelPressedAngle = Math.toDegrees(Math.atan2(wheelPressedY, wheelPressedX));
		wheel.setRotate(wheelPressedAngle-cursorOffset);
		newRot= wheel.getRotate();	
		newTime=new Date();	
		if (dragBeginFlag) 
			{
				oldRot=newRot;
				oldTime=newTime;
				dragBeginFlag=false;
			}	
		else 
			{
			double distance= Math.abs(oldRot-newRot);
			double time = newTime.getTime()-oldTime.getTime();
			this.wheelVelocity = 1000*distance/time;
			oldRot=newRot;
			oldTime=newTime;
			}
		}
		
				
	public void wheelReleased() {
		
		System.out.println(wheelVelocity);
		
		if (wheelVelocity<200)
		{		
			System.out.println("Too slow");
		}
		else if (wheelVelocity==Double.POSITIVE_INFINITY)
		{
			System.out.println("Too fast! You will break the wheel!");
		}
		else
		{
			wheel.wheelRotate(wheelVelocity);
		}		
	}
	
	
	public void stopAnimation() {
		wheel.stopRotate();
	}
	
	public void stopAnimationByKey(KeyEvent evt) {	
		wheel.stopRotate();
	}
	
	
	public void setMain(Main main){
		this.main=main;
	}
	
	public void setPrimaryStage(Stage primaryStage){
		this.primaryStage=primaryStage;
	}
	
	
	public void initialize() {
		
		wheel = new Wheel();
		wheel.setImage(image);
		wheel.setResultLabel(resultLabel);
	}

}
