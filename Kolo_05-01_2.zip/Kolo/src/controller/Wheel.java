package controller;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

public class Wheel {
	
	
	private final String[] fieldValues = {"200", "100", "WYCIECZKA", "150", "250", "300", "AGD", "200", "BANRUT", "1500", "350", "?500",
							"SKUTER", "150", "200", "NAGRODA", "250", "500", "BANKRUT", "400", "?500", "250", "STOP", "400"};
	
	private ImageView image;
	private Label resultLabel;
    private boolean animationRunningFlag=false;
    private Animation animation;
    private RotateTransition transition;
    
    
    
    public void wheelRotate(double wheelVelocity) {
    	
    	transition = new RotateTransition();
		transition.setNode(image);
		transition.setDuration(Duration.seconds(wheelVelocity/100));
		transition.setByAngle(wheelVelocity);
		transition.setCycleCount(1);
		transition.setAutoReverse(false);
		transition.setInterpolator(new Interpolator() {

			@Override
			protected double curve(double t) {
	
				return 1-Math.pow(2.0, -8*t);

			}
			
		});
		animation=transition;
		animation.play();
		animationRunningFlag=true;
		image.setDisable(true);
		
		animation.setOnFinished(e->{
			image.setDisable(false);
			animationRunningFlag=false;

		});		
		
		FieldValuesReader reader = new FieldValuesReader(this);
		resultLabel.textProperty().bind(reader.messageProperty());
		new Thread(reader).start();
    	
    }
    
	public void stopRotate() {
		animation.stop();
		image.setDisable(false);
		animationRunningFlag=false;
	}
    

	
	public Label getResultLabel() {
		return resultLabel;
	}



	public void setResultLabel(Label resultLabel) {
		this.resultLabel = resultLabel;
	}



	public ImageView getImage() {
		return image;
	}


	public void setImage(ImageView image) {
		this.image = image;
	}


	public  boolean isAnimationRunningFlag() {
		return animationRunningFlag;
	}


	public  void setAnimationRunningFlag(boolean animationRunningFlag) {
		this.animationRunningFlag = animationRunningFlag;
	}


	public String getFieldValue(int fieldNumber) {
		
		return fieldValues[fieldNumber];
		
	}
	
	public double getRotate() {
		return image.getRotate();
	}
	
	public void setRotate(double rotate) {
		this.image.setRotate(rotate);
	}	

}
