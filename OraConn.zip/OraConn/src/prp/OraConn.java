package prp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class OraConn {

	private int errCode;
	private String errMsg;
	private Connection connection;
	private String url;
	private String login;
	private String pass;

	public OraConn(String url, String login, String pass) {

		this.url = url;
		this.login = login;
		this.pass = pass;

	}

	public void registerDriver() {

		try

		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}

		catch (ClassNotFoundException ex)

		{
			errCode = 1;
			errMsg = ex.getMessage();
		}
	}

	public void openConnection() {

		try {
			connection = DriverManager.getConnection(url, login, pass);
		}

		catch (SQLException ex) {

			errCode = 2;
			errMsg = ex.getMessage();

		}

	}

	public void closeConnection() {
		try {
			connection.close();
		} catch (SQLException ex) {

			errCode = 3;
			errMsg = ex.getMessage();

		}
	}

	public int getErrCode() {
		return errCode;
	}

	public String getErrMsg() {
		return errMsg;
	}

}
