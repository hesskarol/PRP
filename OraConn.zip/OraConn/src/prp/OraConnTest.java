package prp;

public class OraConnTest {

	public static void main(String[] args) {

		OraConn oraConn = new OraConn("jdbc:oracle:thin:@ora3.elka.pw.edu.pl:1521:ora3inf", "TEMP01", "tem25p01");
		
		oraConn.registerDriver();
		oraConn.openConnection();
		oraConn.closeConnection();
		
	}

}
