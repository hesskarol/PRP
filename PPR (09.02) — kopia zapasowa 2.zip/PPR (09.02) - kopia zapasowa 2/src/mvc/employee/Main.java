package mvc.employee;

import java.util.Optional;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import mvc.employee.model.dal.EmployeesDAL;
import mvc.employee.model.dal.OraConn;
import mvc.employee.view.AlertBox;
import mvc.employee.view.EmployeeController;
import mvc.employee.view.MainController;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class Main extends Application {
	OraConn conn = new OraConn("jdbc:oracle:thin:@ora3.elka.pw.edu.pl:1521:ora3inf", "TEMP01", "temp01");
	
	@Override
	public void start(Stage primaryStage) {
		try {
			// DODANE ======================================
			
			if (conn.openConnection() > 0)
				return;

			ViewLoader<BorderPane, Object> viewLoader = new ViewLoader<BorderPane, Object>("view/Main.fxml");

			BorderPane borderPane = viewLoader.getLayout();

			Scene scene = new Scene(borderPane);
			primaryStage.setScene(scene);
			primaryStage.setTitle("PRACOWNICY");

			primaryStage.setOnHiding(e -> primaryStage_Hiding(e));
			primaryStage.setOnCloseRequest(e -> primaryStage_CloseRequest(e));
			primaryStage.show();

			
			// kod otwierajacy okno danych pracowniczych 
			ViewLoader<AnchorPane, EmployeeController> viewLoaderEmp = 
					new ViewLoader<AnchorPane, EmployeeController>("view/EmployeeData.fxml");
			AnchorPane anchorPaneEmp = viewLoaderEmp.getLayout();
			borderPane.setCenter(anchorPaneEmp);
			((MainController) viewLoader.getController()).setStage(primaryStage);
			
			EmployeeController empController = viewLoaderEmp.getController();
			((MainController)viewLoader.getController()).setStage(primaryStage);
			((MainController)viewLoader.getController()).setEmployeeFXML(viewLoaderEmp);
			// zrodlo danych 
			empController.setEmployees(new EmployeesDAL().getEmployees());
			
			// DODANE KONIEC======================================

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	// DODANE METODY

	int OraDbConnect() {
		
		int ret = conn.openConnection();
		if (ret > 0) {
			AlertBox.showAndWait(AlertType.ERROR, "Nawiązanie połączenia z bazą danych",
					"Nieprawidłowy użytkownik lub hasło.\n" + "[" + conn.getErrCode() + "] " + conn.getErrMsg());
		}
		return ret;
	}

	void primaryStage_Hiding(WindowEvent e) {


		conn.closeConnection();

	}

	void primaryStage_CloseRequest(WindowEvent e) {
	Optional<ButtonType> result = AlertBox.showAndWait(AlertType.CONFIRMATION, "Kończenie 	pracy",
			"Czy chcesz zamknąć aplikację ?");
		if (result.orElse(ButtonType.CANCEL) != ButtonType.OK)
		e.consume();
	}

	// KONIEC DODANYCH METOD
	public static void main(String[] args) {
		launch(args);
	}
}
