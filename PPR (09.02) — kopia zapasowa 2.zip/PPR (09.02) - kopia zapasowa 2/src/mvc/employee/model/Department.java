package mvc.employee.model;

public class Department {
	private int departmentId;
	private String departmentName;
	private int managerId;
	private int locationId;

	public Department() {
	}

	public Department(int departmentId) {
		this.departmentId = departmentId;
	}

	public String toString() {
		return String.valueOf(departmentId);
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}

}
