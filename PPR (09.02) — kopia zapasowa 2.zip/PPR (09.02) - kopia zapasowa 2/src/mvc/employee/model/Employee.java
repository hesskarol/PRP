package mvc.employee.model;

import java.time.LocalDate;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Employee {

	private IntegerProperty employeeId;
	private StringProperty firstName;
	private StringProperty lastName;
	private StringProperty eMail;
	private StringProperty phoneNumber;
	private ObjectProperty<LocalDate> hireDate;
	private StringProperty jobId;
	private DoubleProperty salary;
	private DoubleProperty commissionPct;
	private IntegerProperty managerId;
	private IntegerProperty departmentId;

	// private int employeeId;
	// private String firstName;
	// private String lastName;
	// private String eMail;
	// private String phoneNumber;
	// private LocalDate hireDate;
	// private String jobId;
	// private double salary;
	// private double commissionPct;
	// private int managerId;
	// private int departmentId;

	public Employee() {
		employeeId = new SimpleIntegerProperty(0);
		firstName = new SimpleStringProperty("");
		lastName = new SimpleStringProperty("");
		eMail = new SimpleStringProperty("");
		phoneNumber = new SimpleStringProperty("");
		hireDate = new SimpleObjectProperty<LocalDate>(LocalDate.now());
		jobId = new SimpleStringProperty("");
		salary = new SimpleDoubleProperty();
		commissionPct = new SimpleDoubleProperty();
		managerId = new SimpleIntegerProperty(0);
		departmentId = new SimpleIntegerProperty(0);
	}

	public Employee(int employeeId) {
		this();
		this.employeeId.set(employeeId);

	}

	// METODY ===========
	public int getEmployeeId() {
		return this.employeeId.get();
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId.set(employeeId);
	}

	public IntegerProperty employeeIdProperty() {
		return employeeId;
	}

	public String getFirstName() {
		return this.firstName.get();
	}

	public void setFirstName(String firstName) {
		this.firstName.set(firstName);
	}

	public StringProperty firstNameProperty() {
		return firstName;
	}

	public String getLastName() {
		return this.lastName.get();
	}

	public void setLastName(String lastName) {
		this.lastName.set(lastName);
	}

	public StringProperty LastNameProperty() {
		return lastName;
	}

	public String geteMail() {
		return this.eMail.get();
	}

	public void seteMail(String eMail) {
		this.eMail.set(eMail);
	}

	public StringProperty eMailProperty() {
		return eMail;
	}

	public String getPhoneNumber() {
		return this.eMail.get();
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber.set(phoneNumber);
	}

	public StringProperty PhoneNumberProperty() {
		return phoneNumber;
	}
	
	public LocalDate getHireDate() {
		return this.hireDate.get();
	}

	public void setHireDate(LocalDate hireDate) {
		this.hireDate.set(hireDate);
	}

	public ObjectProperty<LocalDate> HireDateProperty() {
		return hireDate;
	}
	
	public String getJobId() {
		return this.jobId.get();
	}

	public void setJobId(String jobId) {
		this.jobId.set(jobId);
	}

	public StringProperty JobIdProperty() {
		return jobId;
	}
	
	public Double getSalary() {
		return this.salary.get();
	}

	public void setSalary(Double salary) {
		this.salary.set(salary);
	}

	public DoubleProperty SalaryProperty() {
		return salary;
	}
	
	public Double getCommissionPct() {
		return this.commissionPct.get();
	}

	public void setCommissionPct(Double commissionPct) {
		this.commissionPct.set(commissionPct);
	}

	public DoubleProperty CommissionPctProperty() {
		return commissionPct;
	}
	
	public int getManagerId() {
		return this. managerId.get();
	}

	public void setManagerId(int  managerId) {
		this.managerId.set( managerId);
	}

	public IntegerProperty ManagerIdProperty() {
		return  managerId;
	}
	

	public int getDepartmentId() {
		return this.departmentId.get();
	}

	public void setDepartmentId(int  departmentId) {
		this.departmentId.set( departmentId);
	}

	public IntegerProperty DepartmentIdProperty() {
		return  departmentId;
	}

	// public String getFirstName() {
	// return firstName;
	// }
	// public void setFirstName(String firstName) {
	// this.firstName = firstName;
	// }
	// public String getLastName() {
	// return lastName;
	// }
	// public void setLastName(String lastName) {
	// this.lastName = lastName;
	// }
	// public String geteMail() {
	// return eMail;
	// }
	// public void seteMail(String eMail) {
	// this.eMail = eMail;
	// }
	// public String getPhoneNumber() {
	// return phoneNumber;
	// }
	// public void setPhoneNumber(String phoneNumber) {
	// this.phoneNumber = phoneNumber;
	// }
	// public LocalDate getHireDate() {
	// return hireDate;
	// }
	// public void setHireDate(LocalDate hireDate) {
	// this.hireDate = hireDate;
	// }
	// public String getJobId() {
	// return jobId;
	// }
	// public void setJobId(String jobId) {
	// this.jobId = jobId;
	// }
	// public double getSalary() {
	// return salary;
	// }
	// public void setSalary(double salary) {
	// this.salary = salary;
	// }
	// public double getCommissionPct() {
	// return commissionPct;
	// }
	// public void setCommissionPct(double commissionPct) {
	// this.commissionPct = commissionPct;
	// }
	// public int getManagerId() {
	// return managerId;
	// }
	// public void setManagerId(int managerId) {
	// this.managerId = managerId;
	// }
	// public int getDepartmentId() {
	// return departmentId;
	// }
	// public void setDepartmentId(int departmentId) {
	// this.departmentId = departmentId;
	// }

}
