package mvc.employee.model.dal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class OraConn {

	private Connection connection;
	



	private int errCode = 0;
	private String errMsg;
	private String url;
	private String login;
	private String password;
	
	public OraConn(String url, String login, String password)
	{
		this.url = url;
		this.login = login;
		this.password = password;
		
	}
	
	public Connection getConnection() {
		return connection;
	}
	
	public void registerDriver()																			//ladujemy sterowniki

	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

		} catch (ClassNotFoundException ex) {
			
			errCode =1;
			errMsg = ex.getMessage();
		}

	}

	public int openConnection() {																			//otwieramy polaczenie
		try {
			
			connection = DriverManager.getConnection(url, login, password);
			//int x = 2;  //dodalem
			//return x;	//dodalem
		} catch (SQLException ex) {
			errCode =2;
			errMsg =ex.getMessage();
			System.out.println("Blad adresu");
			//int x = 4;		//dodalem
			//return x;		//dodalem
		}
		return errCode;
	}
	
	public void closeConnection() {
		try {
			connection.close();
		} catch (SQLException ex) {
			errCode =3;
			errMsg =ex.getMessage();
			
		}
	}

	public int getErrCode() {
		return errCode;
	}

	

	public String getErrMsg() {
		return errMsg;
	}

	
	
	
	

}
