package controller;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.fxml.FXML;
import javafx.geometry.Point3D;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.util.Duration;

public class RotationWindowController {
	
	private Main main;
	private Stage primaryStage;
	
	@FXML ImageView image;
	@FXML TextField byAngle;
	@FXML TextField duration;
	@FXML Button button;
	
	Animation animation;
	
	double orgSceneX, orgSceneY;
    double orgTranslateX, orgTranslateY;
    double wheelSceneX, wheelSceneY;
    double wheelRotate;
    double trueWheelRotate;
	
	
	
	public void setMain(Main main){
		this.main=main;
	}
	
	public void setPrimaryStage(Stage primaryStage){
		this.primaryStage=primaryStage;
	}
	
	
	public void rotate() {
		
//		System.out.println("Dupa");
		
		RotateTransition transition = new RotateTransition();
		transition.setNode(image);
		transition.setDuration(Duration.seconds(Integer.parseInt(duration.getText())));
//		transition.setFromAngle(0);
//		transition.setToAngle(10);
		transition.setByAngle(Integer.parseInt(byAngle.getText()));
//		transition.setCycleCount(Animation.INDEFINITE);
		transition.setCycleCount(1);
		transition.setAutoReverse(false);
//		transition.setInterpolator(Interpolator.SPLINE(0.9, 0.1, 0.1, 0.5));
		transition.setInterpolator(new Interpolator() {

			@Override
			protected double curve(double t) {
	
				return 1-Math.pow(2.0, -20*t);
//				return Math.abs(0.5-t)*2 ;
//				return -2*t;
			}
			
		});
		animation=transition;
//		System.out.println(byAngle.getText());
//		System.out.println(duration.getText());
		animation.play();	
	}
	
	
	public void wheelPressed(MouseEvent evt) {
		
		wheelSceneX = evt.getSceneX()-250;
		wheelSceneY = evt.getSceneY()-250;
		
		double angleRad = Math.atan2(wheelSceneY, wheelSceneX);
		double angleDegree = Math.toDegrees(angleRad);
		
		wheelRotate = wheelRotate+ angleDegree - trueWheelRotate;
		
		System.out.println(angleDegree + " " + wheelRotate);
		
//		wheelSceneX = evt.getSceneX()-250;
//		wheelSceneY = evt.getSceneY()-250;
//		double distance = Math.sqrt(Math.pow(wheelSceneX, 2)+Math.pow(wheelSceneY, 2)) ;
//		
//		double angleRad = Math.atan2(wheelSceneY, wheelSceneX);
//		double angleDegree = Math.toDegrees(angleRad);
		
		
//		wheelRotate = image.getRotate();
//		double angle = (Math.atan2(wheelSceneX, wheelSceneY))*180/Math.PI;
//		System.out.println(wheelSceneX + " " + wheelSceneY + " " + wheelRotate + " " + distance + " " + angleDegree);
//		image.setRotate(angleDegree);
		
	}
	
	public void wheelDragged(MouseEvent evt) {
		
		wheelSceneX = evt.getSceneX()-250;
		wheelSceneY = evt.getSceneY()-250;
//		double distance = Math.sqrt(Math.pow(wheelSceneX, 2)+Math.pow(wheelSceneY, 2)) ;
		
		double angleRad = Math.atan2(wheelSceneY, wheelSceneX);
		double angleDegree = Math.toDegrees(angleRad);
		image.setRotate(angleDegree-wheelRotate);
//		wheelRotate=0;
//		System.out.println(angleDegree-wheelRotate);
		
		

//		System.out.println(wheelSceneX + " " + wheelSceneY + " " + wheelRotate);
		
//		Point3D rotationAxis = image.getRotationAxis();
//		double  startRotate = image.getRotate();
//		System.out.println(startRotate);
		
				
//		double offsetX = evt.getSceneX() - image.getTranslateX();
//        double offsetY = evt.getSceneY() - image.getTranslateY();
//        double newRotate = Math.atan2(offsetX, offsetY);
//        image.setRotate(newRotate);
//        
//        double value = Math.sqrt(Math.pow(offsetX,2) + Math.pow(offsetY,2));
//        double newWheelRotate = wheelRotate + value;
//        image.setRotate(newWheelRotate);
//        image.setRotate(image.getRotate());
				
	}
	
	public void wheelReleased() {
		trueWheelRotate=image.getRotate();
		wheelRotate=0;
		System.out.println(wheelRotate);
	}
	
	
	public void pressed(MouseEvent evt) {
		
		orgSceneX = evt.getSceneX();
        orgSceneY = evt.getSceneY();
        orgTranslateX = ((Button)(evt.getSource())).getTranslateX();
        orgTranslateY = ((Button)(evt.getSource())).getTranslateY();
        System.out.println(evt.getX() + " " + evt.getY());
        System.out.println(button.getTranslateX() + " " + button.getTranslateY());
        System.out.println(button.getLayoutX() + " " + button.getLayoutY());
        System.out.println("\n");
		
		
	}
	
	public void drag(MouseEvent evt) {
		
		double offsetX = evt.getSceneX() - orgSceneX;
        double offsetY = evt.getSceneY() - orgSceneY;
        double newTranslateX = orgTranslateX + offsetX;
        double newTranslateY = orgTranslateY + offsetY;
         
        ((Button)(evt.getSource())).setTranslateX(newTranslateX);
        ((Button)(evt.getSource())).setTranslateY(newTranslateY);
		
		
		
//		double oldButLayX = button.getLayoutX();
//		double oldButLayY = button.getLayoutY();
//		
//		double onButtonX = evt.getX();
//		double onButtonY = evt.getY();
//		System.out.println(evt.getSceneX() + " " + evt.getSceneY());

		
//		System.out.println(evt.getSceneX() + " " + evt.getSceneY() );
//		button.setLayoutX(evt.getX());
//		button.setLayoutY(evt.getY());
//		button.setLayoutX(evt.getSceneX()-10-a);
//		button.setLayoutY(evt.getSceneY()-10-b);
//		button.setLayoutX(button.getLayoutX()-a);
//		button.setLayoutY(button.getLayoutY()-b);
		
		
	}
	

	
	

}
