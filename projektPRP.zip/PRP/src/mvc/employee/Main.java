package mvc.employee;

import java.util.Optional;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import mvc.employee.model.dal.OraConn;
import mvc.employee.view.AlertBox;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.BorderPane;

public class Main extends Application {

	OraConn oraConn = new OraConn("jdbc:oracle:thin:@ora3.elka.pw.edu.pl:1521:ora3inf", "TEMP01", "temp01");

	public void start(Stage primaryStage) {

		if (oraConn.openConnection() > 0)
			return;

		ViewLoader<BorderPane, Object> viewLoader = new ViewLoader<BorderPane, Object>("view/Main.fxml");
		BorderPane borderPane = viewLoader.getLayout();
		Scene scene = new Scene(borderPane);
		primaryStage.setScene(scene);
		primaryStage.setTitle("Pracownicy");
		primaryStage.setOnHiding(e -> primaryStage_Hiding(e));
		primaryStage.setOnCloseRequest(e -> primaryStage_CloseRequest(e));
		primaryStage.show();
	}

	int OraDbConnect() {

		int ret = oraConn.openConnection();
		if (ret > 0) {
			AlertBox.showAndWait(AlertType.ERROR, "Nawiązanie połączenia z bazą danych",
					"Nieprawidłowy użytkownik lub hasło.\n" + "[" + oraConn.getErrCode() + "] " + oraConn.getErrMsg());
		}
		return ret;
	}

	void primaryStage_Hiding(WindowEvent e) {
		oraConn.closeConnection();
	}

	void primaryStage_CloseRequest(WindowEvent e) {
		Optional<ButtonType> result = AlertBox.showAndWait(AlertType.CONFIRMATION, "Kończenie pracy",
				"Czy chcesz zamknąć aplikację?");
		if (result.orElse(ButtonType.CANCEL) != ButtonType.OK)
			e.consume();
	}

	public static void main(String[] args) {
		launch(args);
	}
}
