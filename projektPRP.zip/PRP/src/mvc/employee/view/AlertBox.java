package mvc.employee.view;

import java.util.Optional;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;

public class AlertBox {


	public static Optional<ButtonType> showAndWait(AlertType alertType, String title, String text) {
		
		Alert alertDialog = new Alert(alertType);

		alertDialog.setTitle(title);
		alertDialog.setContentText(text);
		alertDialog.setHeaderText(null);
		return alertDialog.showAndWait();	

	}}







 