package mvc.employee.view;

import javafx.fxml.FXML;

public class EmployeeController {
	@FXML
	private void initialize(){
		
	}

}
