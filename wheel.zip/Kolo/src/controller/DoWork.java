package controller;

import javafx.concurrent.Task;
import javafx.scene.image.ImageView;

public class DoWork extends Task<Void>{
	
	
	ImageView image;
	double wheelRotateValue;
	double position;
	int spins, fieldNumber;
	
	public DoWork(ImageView image) {
		this.image=image;
	}

	@Override
	protected Void call() throws Exception {
		
		
		while (RotationWindowController.isAnimationRunFlag())
		{

			position=image.rotateProperty().get();
			spins = (int)position/360;
			position= position- spins*360;
			fieldNumber = (int)position/15;
			String text = Wheel.getFieldValue(23-fieldNumber);		
			updateMessage(text);
			
		}
		
		return null;
	
	}


}
