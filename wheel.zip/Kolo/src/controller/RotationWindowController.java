package controller;

import java.util.Date;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.util.Duration;

public class RotationWindowController {
	
	private Main main;
	private Stage primaryStage;
	
	@FXML ImageView image;
	@FXML Button stopButton;
	@FXML Label resultLabel;
	
	
	private Animation animation;
	private double wheelSceneX, wheelSceneY;
	private double angleDegree;
	private double cursorOffset;
	private double spinStopAngle;
	private double spinStartAngle;
	private double oldRot;
	private double newRot;
	private boolean flag = true;
	private Date oldTime;
	private Date newTime;
	private double velocity;
    private static boolean animationRunFlag=false;
	


	public static boolean isAnimationRunFlag() {
		return animationRunFlag;
	}


	public void wheelPressed(MouseEvent evt) {
		
		cursorOffset=0;
		wheelSceneX = evt.getSceneX()-250;
		wheelSceneY = evt.getSceneY()-250;
		angleDegree = Math.toDegrees(Math.atan2(wheelSceneY, wheelSceneX));
		cursorOffset =  angleDegree - spinStopAngle;
		spinStartAngle = image.getRotate();
		
	}
	
	public void wheelDragged(MouseEvent evt) 
		{
		wheelSceneX = evt.getSceneX()-250;
		wheelSceneY = evt.getSceneY()-250;		
		angleDegree = Math.toDegrees(Math.atan2(wheelSceneY, wheelSceneX));
		image.setRotate(angleDegree-cursorOffset);
		newRot= image.getRotate();
		newTime=new Date();	
		if (flag) 
			{
				oldRot=newRot;
				oldTime=newTime;
				flag=false;
			}	
		else 
			{
			double distance= Math.abs(oldRot-newRot);
			double time = newTime.getTime()-oldTime.getTime();
			this.velocity = 1000*distance/time;
			oldRot=newRot;
			oldTime=newTime;
			}
		}
		
				
	public void wheelReleased() {
		spinStopAngle=image.getRotate();
		
		if (velocity<300)
		{		
			System.out.println("Too slow");
		}
		else 
		{
			rotate(velocity);
		}
		
	}
	
	public void rotate(double velocity) {
		
		RotateTransition transition = new RotateTransition();
		transition.setNode(image);
		transition.setDuration(Duration.seconds(velocity/100));
		transition.setByAngle(velocity);
		transition.setCycleCount(1);
		transition.setAutoReverse(false);
		transition.setInterpolator(new Interpolator() {

			@Override
			protected double curve(double t) {
	
				return 1-Math.pow(2.0, -8*t);

			}
			
		});
		animation=transition;
		animation.play();
		animationRunFlag=true;
		image.setDisable(true);
		
		animation.setOnFinished(e->{
			spinStopAngle=image.getRotate();
			image.setDisable(false);
			animationRunFlag=false;

		});
		
		
		DoWork task = new DoWork(image);
		resultLabel.textProperty().bind(task.messageProperty());
		new Thread(task).start();
		
	}
	
	
	public void stopAnimation() {
		animation.stop();
		spinStopAngle=image.getRotate();
		image.setDisable(false);
		animationRunFlag=false;
		System.out.println(image.getRotate());
		
	}
	
	public void setMain(Main main){
		this.main=main;
	}
	
	public void setPrimaryStage(Stage primaryStage){
		this.primaryStage=primaryStage;
	}
	
	public void initialize() {
	}

}
