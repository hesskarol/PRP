package controller;

public class Wheel {
	
	
	private static final String[] fieldValues = {"200", "100", "WYCIECZKA", "150", "250", "300", "AGD", "200", "BANRUT", "1500", "350", "?500",
							"SKUTER", "150", "200", "NAGRODA", "250", "500", "BANKRUT", "400", "?500", "250", "STOP", "400"};
	
	
	
	
	public static String getFieldValue(int fieldNumber) {
		
		return fieldValues[fieldNumber];
		
	}
	
	
	
	
	

}
